//Expressions - Modulo Operator 

var remainder = 9 % 2;
console.log(remainder);  