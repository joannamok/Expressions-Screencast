 // Expressions - Assignment Opertaors 

 var a = 3;
 a *= 4; // a = a * 4
 console.log(a);