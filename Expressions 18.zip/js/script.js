 // Expressions - Assignment Opertaors 

 var a = 3;
 a ++ ; // a = a + 1 // a + = 1 
 //a --; //a - 1 // a - = 1
 console.log(a);