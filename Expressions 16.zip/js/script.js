 // Expressions - Assignment Opertaors 

 var a = 3;
 a = a + 4;
 console.log(a);