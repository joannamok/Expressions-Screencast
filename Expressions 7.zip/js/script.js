//Expressions - Arithmetic Operrators

// area of the tiangle is 1/2w(h)
var width = 4;
var height = 5;
var area = width * height/2;
console.log(area);