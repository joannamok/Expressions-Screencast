//Expressions - Modulo Operator 

var remainder = 32 % 10;
console.log(remainder);  