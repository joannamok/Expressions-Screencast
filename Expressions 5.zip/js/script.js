//Expressions - Age Example 

var yearBorn = 1974;
var age = 2013 - yearBorn - 1;
console.log(age);