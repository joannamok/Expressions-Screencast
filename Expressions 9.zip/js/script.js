//Expressions - Modulo Operator 

var remainder = 212 % 2;
console.log(remainder);  