 // Concatenating Strings

 var a = 6;
 var b = 7;

 var result = a + b;
 console.log(result);
