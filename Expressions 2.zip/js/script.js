//Expressions

var a = 2; // sets up our variable a and defines it with 2
a = a + 3; //add 3 to a 
console.log(a)