 // Concatenating Strings

 var firstName = "Joanna";
 var lastName = "Lacey";
 var fullName = firstName + " " + lastName;

 console.log(fullName)